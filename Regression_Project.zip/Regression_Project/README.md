This is a regression project for my machine learning class.
